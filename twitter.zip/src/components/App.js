import React from 'react';
import Layout from "./layout/Layout";
import {BrowserRouter, Route, Switch} from "react-router-dom";
import Home from "../pages/home/Home";
import Page404 from "../pages/page404/Page404";
import TwitsByHashTag from "../pages/twitsByHashTag/TwitsByHashTag";
import TwitsByUser from "../pages/twitsByUser/TwitsByUser";
import AuthPage from "../pages/auth/AuthPage";
import "react-toastify/dist/ReactToastify.css";
import {ToastContainer} from "react-toastify";

const App = () => {
    return (
        <>
            <BrowserRouter>
                <Switch>
                    <Route path={"/login"} component={AuthPage}/>
                    <Route path={"/"} render={()=>
                        <Layout>
                             <Switch>
                                 <Route exact path={"/"} component={Home}/>
                                 <Route exact path={"/hashtags/:hashtag"} component={TwitsByHashTag}/>
                                 <Route exact path={"/users/:user"} component={TwitsByUser}/>
                                 <Route  component={Page404}></Route>
                              </Switch>
                    </Layout>
                 }/>
                </Switch>
            </BrowserRouter>
            <ToastContainer/>
        </>
    );
};

export default App;