import React, {useEffect, useState} from 'react';
import useStyles from "./style";
import {Grid} from "@material-ui/core";
import Typography from "@material-ui/core/Typography";
import Divider from "@material-ui/core/Divider";
import ButtonBase from "@material-ui/core/ButtonBase";
import {Link} from "react-router-dom";
import axios from "axios";
import {getUsers} from "../../api/api_twit";


const Twitter = ({name,id,img}) =>{
    const classes=useStyles();
    return <ButtonBase><Grid container className={classes.twitterParent}>
        <img src={img} style={{width:'50'}}/>
        <Grid item container direction={"column"}  className={classes.twitterNameParent}>
            <Typography className={classes.profName}>{name}</Typography>
            <Typography className={classes.profId}>{id}</Typography>
        </Grid>
    </Grid>
    </ButtonBase>
}

const LeftSidebar = () => {
    const classes=useStyles();
    const [users,setUsers]=useState([]);
    useEffect( () => {
       getUsers((isOk,data) => {
           if(!isOk)
               return alert("ناموفق!");
           setUsers(data);
       })
    },[]);
    return (
        <div className={classes.root}>
            <Grid container direction={"row-reverse"}>
                <img src={'/images/user img.png'} style={{width:'max-Content'}}/>
                <Grid item container direction={"column"}  className={classes.profText}>
               <Typography className={classes.profName}>محمد مطواعی</Typography>
               <Typography className={classes.profId}>Mohammad.metvayi</Typography>
                </Grid>
            </Grid>
            <Grid container direction={"column"} className={classes.twitterRoot}>
                <Typography className={classes.twitterTitle}>
                    بهترین خبرنگاران
                </Typography>
                <Divider/>
                {
                    users.map((item,index) => {
                        return (<Link to={`/users/${item.name}`} style={{width: "100%"}}>
                        <Twitter name={item.name} id={item.id} img={item.img}/>
                            {index !== users.length - 1 &&
                            <Divider/>
                            }
                        </Link>)
                    })
                }

            </Grid>
        </div>
    );
};

export default LeftSidebar;