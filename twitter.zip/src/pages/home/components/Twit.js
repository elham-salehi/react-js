import React from 'react';
import Grid from "@material-ui/core/Grid";
import Button from "@material-ui/core/Button";
import {IconButton} from "@material-ui/core";
import useStyles from "../style";
import Typography from "@material-ui/core/Typography";
import FavoriteIcon from "@material-ui/icons/Favorite"

const Twit = ({data}) => {
    const renderTwit= (text) => {
        return {__html:text .replace(/#\S+/g,"<a href='tags/$&' style='color:cornflowerblue'>$&</a>")};

    }
    const classes= useStyles();
    return (
        <div className={classes.twitItem}>
            <Grid container>
                    <img src={data.sender.img} style={{height:'max-Content'}}/>
                <Grid item container direction={"column"} style={{flex: 1,marginRight: '1rem'}}>
                    <Grid item container>
                        <Typography className={classes.twitItemName}>{data.sender.name}</Typography>
                        <Typography className={classes.twitItemId}>{data.sender.id}</Typography>
                    </Grid>
                    <Typography dangerouslySetInnerHTML={renderTwit(data.text)} className={classes.twitText} component={"p"}></Typography>
                </Grid>
            </Grid>
                <Grid container direction={"row-reverse"} style={{marginTop:16}} alignItems={"center"}>
                    <IconButton className={classes.newTwitImgBtn}>
                        <img src={"/images/retwit.png"}/>
                    </IconButton>
                    <IconButton  className={classes.newTwitImgBtn}>
                        <FavoriteIcon/>
                    </IconButton>
                    <Typography className={classes.likeCount}>
                        {data.likes}
                    </Typography>
                </Grid>
        </div>
    );
};

export default Twit;