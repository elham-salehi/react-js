import React, {useEffect, useState} from 'react';
import useStyles from "./style";
import Header from "../../components/header/Header";
import Divider from "@material-ui/core/Divider";
import NewTwit from "./components/NewTwit";
import TwitList from "./components/TwitList";
import HomeIcon from '@material-ui/icons/Home'
import axios from "axios";
import {getAllTwits} from "../../api/api_twit";

const Home = () => {
    const classes= useStyles();

    const [twits,setTwits]=useState([]);
    useEffect( () => {
        getAllTwits((isOk,data) => {
            if(!isOk)
                return alert(data.message);
            setTwits(data);
        })
    },[]);
    return (
        <div className={classes.root}>
           <Header title={"خانه"} icon={<HomeIcon/>}/>
           <Divider className={classes.divider}/>
           <NewTwit/>
           <TwitList data={twits}/>
        </div>
    );
};

export default Home;