import React, {useEffect, useState} from 'react';
import useStyles from "../home/style";
import Header from "../../components/header/Header";
import Divider from "@material-ui/core/Divider";
import TwitList from "../home/components/TwitList";
import PersonIcon from "@material-ui/icons/Person"
import {getAllTwits} from "../../api/api_twit";

const TwitsByUser = (props) => {
    const classes= useStyles();

    const [twits,setTwits]=useState([]);
    useEffect( () => {
        getAllTwits((isOk,data) => {
            if(!isOk)
                return alert(data.message)
            else setTwits(data);
        })
    },[]);

    return (
        <div className={classes.root}>
            <Header title={props.match.params.user} icon={<PersonIcon/>}/>
            <Divider className={classes.divider}/>
            <TwitList data={twits}/>
        </div>
    );
};

export default TwitsByUser;