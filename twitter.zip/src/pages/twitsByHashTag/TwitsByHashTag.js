import React, {useEffect, useState} from 'react';
import useStyles from "../home/style";
import Header from "../../components/header/Header";
import Divider from "@material-ui/core/Divider";
import TwitList from "../home/components/TwitList";
import axios from "axios";
import {getAllTwits} from "../../api/api_twit";

const TwitsByHashTag = (props) => {

    const [twits,setTwits]=useState([]);
    useEffect( () => {
       getAllTwits((isOk,data) => {
           if(!isOk)
               return alert(data.message);
                setTwits(data);
       })
    },[]);

    const classes= useStyles();
    return (
        <div className={classes.root}>
            <Header title={props.match.params.hashtag} icon={<img src={"/images/hashtag.png"}/>}/>
            <Divider className={classes.divider}/>
            <TwitList data={twits}/>
        </div>
    );
};

export default TwitsByHashTag;