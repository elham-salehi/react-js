import React from 'react';

const Page404 = () => {
    return (
        <div>
            <h3>صفحه پیدا نشد!</h3>
        </div>
    );
};

export default Page404;