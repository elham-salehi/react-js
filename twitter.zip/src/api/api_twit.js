
 import {getAxiosInstanceJsonServer} from "./api";
import axios from "axios";

export const getAllTwits= (callback) => {
    getAxiosInstanceJsonServer().get("/twits")
        .then(response => {
            const data = response.data;
            callback(true,data);
        }).catch(error => {
        console.log(error);
        callback(false,error);
    })
};

export const getHashTags= (callback) => {
    getAxiosInstanceJsonServer().get("/hashTags")
        .then(response =>{
            const data= response.data;
            callback(true,data);
        }).catch(error =>{
        console.log(error);
        callback(false,error)
    })

};
export const getUsers= (callback) => {
    getAxiosInstanceJsonServer().get("/users")
        .then(response =>{
            const data= response.data;
            callback(true,data);
        }).catch(error =>{
        console.log(error);
        callback(false,error)
    })

};
export const newTwitRequest= (data,callback) => {
    getAxiosInstanceJsonServer().post("/twits",data)
        .then(res =>{
            callback(true);
        }).catch(error =>{
        callback(false);
    });

};