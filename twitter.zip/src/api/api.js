import Axios from "axios";

export const getAxiosInstanceJsonServer = () => {
   return  Axios.create({
        baseURL: "https://twitterapi.liara.run/",
        headers: {
            API_KEY: "sfegrrgthstejhserhawtgwrg"
        }
    });
};
export const getAxiosInstanceAuth = () => {
    return  Axios.create({
        baseURL: "https://twitterapi.liara.run/api",
        headers: {
            //API_KEY: "sfegrrgthstejhserhawtgwrg"
        }
    });
};